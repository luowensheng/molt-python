"""Hello PyExec package."""

__version__ = "1.0.0"
