"""Hello PyExec - A simple example application."""

import sys
import requests
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()


def main():
    """Main entry point for the application."""
    console.print(Panel.fit(
        "[bold cyan]Hello from PyExec![/bold cyan]",
        border_style="cyan"
    ))
    
    # Display system information
    table = Table(title="System Information", show_header=True)
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="green")
    
    table.add_row("Python Version", sys.version.split()[0])
    table.add_row("Platform", sys.platform)
    table.add_row("Requests Version", requests.__version__)
    
    console.print(table)
    
    # Test network request
    console.print("\n[yellow]Testing GitHub API...[/yellow]")
    try:
        response = requests.get("https://api.github.com", timeout=5)
        if response.status_code == 200:
            console.print(f"[green]✓ GitHub API Status: {response.status_code}[/green]")
            
            # Show rate limit info
            limit_table = Table(show_header=False)
            limit_table.add_column("Property", style="cyan")
            limit_table.add_column("Value", style="yellow")
            
            limit_table.add_row("Rate Limit", response.headers.get("X-RateLimit-Limit", "N/A"))
            limit_table.add_row("Remaining", response.headers.get("X-RateLimit-Remaining", "N/A"))
            
            console.print(limit_table)
        else:
            console.print(f"[red]✗ Status: {response.status_code}[/red]")
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
    
    console.print("\n[bold green]PyExec is working correctly![/bold green]")


if __name__ == "__main__":
    main()
