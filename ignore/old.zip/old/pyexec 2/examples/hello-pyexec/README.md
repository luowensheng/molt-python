# Hello PyExec Example

A simple example application demonstrating PyExec's capabilities.

## Features

- Uses requests library for HTTP requests
- Uses rich library for beautiful terminal output
- Demonstrates system information display
- Tests network connectivity

## Building

```bash
# Install UV if not already installed
pip install uv

# Initialize project
uv init
uv lock

# Build with PyExec
pyexec build --profile standard .
```

## Running

```bash
# Install
./hello-pyexec-v1.0.0 install

# Run
./hello-pyexec-v1.0.0 run
```

## Expected Output

The application will display:
- A welcome message
- System information (Python version, platform, etc.)
- GitHub API test results
- Rate limit information

## Distribution

The resulting binary is self-contained and can be distributed to any Linux system:

```bash
# Copy to another machine
scp hello-pyexec-v1.0.0 user@server:~/

# Install and run on the remote machine
ssh user@server
./hello-pyexec-v1.0.0 install
./hello-pyexec-v1.0.0 run
```
