# PyExec Architecture

This document describes the internal architecture and design decisions of PyExec.

## Overview

PyExec is built in Go and consists of several key components that work together to capture, package, and execute Python applications in isolated environments.

## Components

### 1. Builder (`pkg/builder`)

The Builder orchestrates the entire build process:

```
┌─────────────────────────────────────┐
│          Builder                    │
├─────────────────────────────────────┤
│  • Validates project structure      │
│  • Orchestrates capture             │
│  • Generates manifest                │
│  • Coordinates packaging            │
└─────────────────────────────────────┘
           │
           ├──> Capturer
           ├──> Manifest Generator
           └──> Packager
```

**Key Functions:**
- `Build()`: Main build orchestration
- `validateProject()`: Ensures project has required files
- Profile normalization

### 2. Capturer (`pkg/capture`)

Captures the complete Python environment:

```
┌─────────────────────────────────────┐
│          Capturer                   │
├─────────────────────────────────────┤
│  1. capturePython()                 │
│     • Find Python binary            │
│     • Get version                   │
│     • Calculate checksum            │
│     • Generate download URL         │
│                                     │
│  2. captureSystemDeps()             │
│     • Run ldd on Python             │
│     • Trace native extensions       │
│     • Get library checksums         │
│                                     │
│  3. capturePackages()               │
│     • Parse uv.lock                 │
│     • Extract package info          │
│     • Get download URLs             │
│                                     │
│  4. captureSource()                 │
│     • Walk project directory        │
│     • Collect Python files          │
│     • Calculate total size          │
└─────────────────────────────────────┘
```

**Key Data Structures:**
```go
type Snapshot struct {
    Python     PythonInfo
    SystemDeps []SystemDep
    Packages   []Package
    Source     SourceInfo
}
```

### 3. Manifest (`pkg/manifest`)

Represents the captured environment in a serializable format:

```json
{
  "version": "1.0",
  "python": {
    "version": "3.12.1",
    "url": "https://...",
    "checksum": "abc123...",
    "size": 45000000
  },
  "system_deps": [
    {
      "name": "libssl.so.3",
      "checksum": "def456...",
      "size": 2000000
    }
  ],
  "packages": [
    {
      "name": "requests",
      "version": "2.31.0",
      "url": "https://pypi.org/...",
      "checksum": "ghi789...",
      "size": 100000
    }
  ],
  "source": {
    "files": ["main.py", "..."],
    "size": 50000
  }
}
```

### 4. Packager (`pkg/packager`)

Creates the final executable:

```
┌─────────────────────────────────────┐
│          Packager                   │
├─────────────────────────────────────┤
│  1. Create temp build directory     │
│  2. Write manifest.json             │
│  3. Create source.tar.gz            │
│  4. Embed components (optional)     │
│     • Python binary                 │
│     • System libraries              │
│     • Python packages               │
│  5. Generate Go wrapper             │
│  6. Compile final binary            │
└─────────────────────────────────────┘
```

**Wrapper Structure:**
```go
// Generated wrapper includes:
- Embedded manifest
- Embedded source code
- Optional embedded dependencies
- Install command
- Run command
- Version command
- Verify command
```

### 5. Installer (`pkg/installer`)

Handles installation on target systems:

```
┌─────────────────────────────────────┐
│         Installer                   │
├─────────────────────────────────────┤
│  1. installPython()                 │
│     • Check cache                   │
│     • Download if needed            │
│     • Verify checksum               │
│     • Extract to install dir        │
│                                     │
│  2. installSystemDeps()             │
│     • Download libraries            │
│     • Place in lib/ directory       │
│     • Verify checksums              │
│                                     │
│  3. createVenv()                    │
│     • Create .venv directory        │
│     • Link Python binary            │
│                                     │
│  4. installPackages()               │
│     • Download wheels               │
│     • Install with pip/uv           │
│     • Verify installation           │
│                                     │
│  5. verify() (exact mode only)      │
│     • Check all checksums           │
│     • Generate audit log            │
└─────────────────────────────────────┘
```

**Installation Modes:**

| Mode | Isolation | Verification | Use Case |
|------|-----------|--------------|----------|
| minimal | Basic | None | Development |
| standalone | Full | Basic | Production |
| exact | Full | Complete | Critical systems |

### 6. Executor (`pkg/executor`)

Executes the Python application:

```
┌─────────────────────────────────────┐
│          Executor                   │
├─────────────────────────────────────┤
│  1. verifyInstallation()            │
│     • Check directories exist       │
│     • Verify Python binary          │
│     • Check manifest                │
│                                     │
│  2. buildEnvironment()              │
│     • Set LD_LIBRARY_PATH           │
│     • Set PYTHONHOME                │
│     • Set PATH                      │
│     • Prevent system site-packages  │
│                                     │
│  3. setupNamespace() (Linux only)   │
│     • CLONE_NEWNS (filesystem)      │
│     • CLONE_NEWPID (processes)      │
│     • CLONE_NEWUTS (hostname)       │
│                                     │
│  4. execute()                       │
│     • Run Python with args          │
│     • Connect stdio                 │
└─────────────────────────────────────┘
```

## Build Process Flow

```
┌──────────────┐
│   Project    │
│ Directory    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Validate    │
│   Project    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Capture    │
│ Environment  │  → Snapshot
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Generate    │
│  Manifest    │  → JSON
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Package    │
│    Binary    │  → Executable
└──────────────┘
```

## Install Process Flow

```
┌──────────────┐
│   Binary     │
│  Execution   │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Read        │
│  Manifest    │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Download    │
│ Components   │  ← Cache
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Create      │
│  Structure   │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│   Verify     │
│   Install    │
└──────────────┘
```

## Run Process Flow

```
┌──────────────┐
│   Binary     │
│  Execution   │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Verify      │
│ Installation │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Setup       │
│  Namespace   │  (Linux only)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Configure   │
│ Environment  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Execute     │
│   Python     │
└──────────────┘
```

## Data Flow

### Build Time

```
Project Files
    │
    ▼
[Capture] → Snapshot → [Manifest Generator] → JSON
    │                                          │
    └──────────────────────────────────────────┴─→ [Packager]
                                                      │
                                                      ▼
                                                   Binary
```

### Install Time

```
Binary (embedded manifest)
    │
    ▼
[Read Manifest] → Download URLs
    │
    ▼
[Downloader] → Files → [Verifier] → [Installer]
    │                                    │
    └─→ [Cache]                          ▼
                                   Installation
```

### Run Time

```
Binary → [Read Config] → Installation Path
                              │
                              ▼
                         [Executor]
                              │
                              ▼
                      Python Process
```

## Design Decisions

### 1. Why Go?

- **Single Binary**: Easy to distribute
- **Cross-compilation**: Build for multiple platforms
- **Performance**: Fast startup and execution
- **Standard Library**: Excellent for building CLIs

### 2. Why UV Lock Files?

- **Deterministic**: Exact versions with checksums
- **Fast**: UV is significantly faster than pip
- **Standard**: Uses standard Python packaging

### 3. Why Linux Namespaces?

- **Isolation**: Prevent conflicts with host system
- **No Root**: User namespaces don't require root
- **Lightweight**: Much lighter than containers
- **Standard**: Built into Linux kernel

### 4. Why Lazy Download?

- **Bandwidth**: Only download what's needed
- **Caching**: Reuse downloads across installations
- **Flexibility**: Different profiles for different needs

## Security Considerations

### 1. Checksum Verification

All downloads are verified with SHA256 checksums to prevent tampering.

### 2. Signature Support

Binaries can be signed with private keys and verified before installation.

### 3. Namespace Isolation

Linux namespaces provide process, filesystem, and network isolation.

### 4. Read-only Enforcement

Critical files can be made read-only to prevent modification.

## Performance Optimizations

### 1. Caching

- Content-addressable storage
- Shared cache across installations
- Deduplication of common dependencies

### 2. Parallel Downloads

- Multiple concurrent downloads
- Configurable concurrency limit

### 3. Lazy Materialization

- Only download what's needed
- Profile-based embedding strategies

## Future Enhancements

### Short Term

- [ ] Complete installer implementation
- [ ] Add real namespace support
- [ ] Implement signature verification
- [ ] Add comprehensive tests

### Medium Term

- [ ] Support ARM64 architecture
- [ ] Add Windows support (limited)
- [ ] Implement update mechanism
- [ ] Add telemetry and monitoring

### Long Term

- [ ] Plugin system
- [ ] Custom dependency sources
- [ ] Integration with cloud storage
- [ ] Kubernetes operator

## Comparison with Similar Tools

### vs Nix

- **PyExec**: Python-specific, simpler
- **Nix**: Universal, more complex

### vs Bazel

- **PyExec**: Runtime distribution
- **Bazel**: Build system

### vs Docker

- **PyExec**: Lighter, faster
- **Docker**: More isolation, more overhead

## References

- [UV Documentation](https://github.com/astral-sh/uv)
- [Python Build Standalone](https://github.com/indygreg/python-build-standalone)
- [Linux Namespaces](https://man7.org/linux/man-pages/man7/namespaces.7.html)
