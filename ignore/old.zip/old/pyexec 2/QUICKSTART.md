# PyExec Quick Start Guide

Get started with PyExec in 5 minutes.

## Installation

### Option 1: Build from Source

```bash
git clone https://pyexec
cd pyexec
make build
sudo make install
```

### Option 2: Download Pre-built Binary

```bash
# Download latest release
curl -LO https://pyexec/releases/latest/download/pyexec-linux-amd64

# Make executable
chmod +x pyexec-linux-amd64

# Move to PATH
sudo mv pyexec-linux-amd64 /usr/local/bin/pyexec
```

### Verify Installation

```bash
pyexec version
# Output: PyExec version 0.1.0 (built 2024-01-09)
```

## Your First PyExec Application

### 1. Create a Python Project

```bash
# Create project directory
mkdir my-first-app
cd my-first-app

# Create pyproject.toml
cat > pyproject.toml << 'EOF'
[project]
name = "my-first-app"
version = "1.0.0"
requires-python = ">=3.12"
dependencies = [
    "requests>=2.31.0",
]
EOF

# Create source code
mkdir app
cat > app/__init__.py << 'EOF'
__version__ = "1.0.0"
EOF

cat > app/main.py << 'EOF'
import requests

def main():
    print("Hello from PyExec!")
    resp = requests.get("https://httpbin.org/get")
    print(f"Status: {resp.status_code}")

if __name__ == "__main__":
    main()
EOF
```

### 2. Initialize with UV

```bash
# Install UV if you haven't
pip install uv

# Initialize and lock dependencies
uv init
uv lock
```

Your project should now look like:
```
my-first-app/
├── pyproject.toml
├── uv.lock
└── app/
    ├── __init__.py
    └── main.py
```

### 3. Build with PyExec

```bash
pyexec build --profile standard .
```

Expected output:
```
Building my-first-app...
✓ Validating project structure...
✓ Capturing environment...
✓ Generating manifest...
✓ Packaging binary...

✓ Build successful!
  Binary: ./my-first-app-v1.0.0 (25.3 MB)
  Profile: standard
  Python: 3.12.1
  Packages: 5
  System deps: 10
```

### 4. Install and Run

```bash
# Install the application
./my-first-app-v1.0.0 install

# Run it
./my-first-app-v1.0.0 run
```

Expected output:
```
Hello from PyExec!
Status: 200
```

## Congratulations! 🎉

You've just created your first PyExec application!

## Next Steps

### Try Different Profiles

```bash
# Minimal profile (smallest binary)
pyexec build --profile minimal .

# Extended profile (for edge deployment)
pyexec build --profile extended .

# Full profile (completely offline)
pyexec build --profile full --offline .
```

### Distribute Your Application

```bash
# Copy to another machine
scp my-first-app-v1.0.0 user@server:~/

# On the remote machine
ssh user@server
chmod +x my-first-app-v1.0.0
./my-first-app-v1.0.0 install
./my-first-app-v1.0.0 run
```

### Try the Example

```bash
cd examples/hello-pyexec
pyexec build --profile standard .
./hello-pyexec-v1.0.0 install
./hello-pyexec-v1.0.0 run
```

## Common Commands

```bash
# Build with specific version
pyexec build --version 1.2.3 .

# Build with custom name
pyexec build --name my-app .

# Build offline bundle
pyexec build --profile full --offline .

# Check version
pyexec version

# Get help
pyexec --help
pyexec build --help
```

## Troubleshooting

### "pyproject.toml not found"

Make sure you're in the project directory and have created `pyproject.toml`.

### "uv.lock not found"

Run `uv init && uv lock` to create the lock file.

### "Python not found"

Install Python 3.12 or later:
```bash
# Ubuntu/Debian
sudo apt install python3.12

# Fedora
sudo dnf install python3.12
```

### Build fails

Check that you have Go 1.21+ installed:
```bash
go version
```

## Learn More

- [Full Documentation](README.md)
- [Architecture Details](ARCHITECTURE.md)
- [Contributing Guide](CONTRIBUTING.md)
- [Example Projects](examples/)

## Support

- Report bugs: [GitHub Issues](https://pyexec/issues)
- Ask questions: [GitHub Discussions](https://pyexec/discussions)
- Read docs: [README.md](README.md)

## What Makes PyExec Special?

- ⚡ **Fast**: 30-60 second builds vs 5-15 minute Docker builds
- 💾 **Small**: 5-150MB binaries vs 500MB-2GB Docker images
- 🔒 **Isolated**: Full environment isolation, no conflicts
- 🚀 **Easy**: Single binary, no dependencies
- 🔄 **Reproducible**: 95%+ reproducibility across systems
- 🎯 **Practical**: Works with standard Python projects

Happy building! 🚀
