# PyExec Project Structure

```
pyexec/
├── cmd/                          # Command-line interface
│   ├── root.go                   # Root command setup
│   ├── build.go                  # Build command implementation
│   └── version.go                # Version command
│
├── pkg/                          # Core packages
│   ├── builder/                  # Build orchestration
│   │   └── builder.go            # Main builder logic
│   │
│   ├── capture/                  # Environment capture
│   │   └── capture.go            # Captures Python environment
│   │
│   ├── manifest/                 # Manifest generation
│   │   └── manifest.go           # Manifest data structures
│   │
│   ├── packager/                 # Binary packaging
│   │   └── packager.go           # Creates final binary
│   │
│   ├── installer/                # Installation on target systems
│   │   └── installer.go          # Installs application
│   │
│   └── executor/                 # Application execution
│       └── executor.go           # Runs Python application
│
├── examples/                     # Example projects
│   └── hello-pyexec/             # Simple example
│       ├── hello/
│       │   ├── __init__.py
│       │   └── main.py
│       ├── pyproject.toml
│       └── README.md
│
├── main.go                       # Entry point
├── go.mod                        # Go dependencies
├── Makefile                      # Build automation
│
├── README.md                     # Main documentation
├── ARCHITECTURE.md               # Architecture details
├── CONTRIBUTING.md               # Contribution guidelines
├── LICENSE                       # MIT License
│
└── .gitignore                    # Git ignore rules
```

## Key Files

### Entry Point
- `main.go`: Application entry point, calls cmd.Execute()

### Commands
- `cmd/root.go`: Sets up Cobra command structure
- `cmd/build.go`: Implements `pyexec build` command
- `cmd/version.go`: Implements `pyexec version` command

### Core Logic
- `pkg/builder/builder.go`: Orchestrates the entire build process
- `pkg/capture/capture.go`: Captures Python environment details
- `pkg/manifest/manifest.go`: Defines manifest data structures
- `pkg/packager/packager.go`: Creates the final Go binary
- `pkg/installer/installer.go`: Handles installation on target systems
- `pkg/executor/executor.go`: Executes Python applications

### Documentation
- `README.md`: User-facing documentation
- `ARCHITECTURE.md`: Technical architecture details
- `CONTRIBUTING.md`: Guide for contributors

## Data Flow

### 1. Build Phase
```
Project → Capturer → Snapshot → Manifest → Packager → Binary
```

### 2. Install Phase
```
Binary → Manifest → Downloader → Installer → Environment
```

### 3. Run Phase
```
Binary → Executor → Python Process
```

## Component Interactions

```
┌─────────────────────────────────────────────────────────┐
│                     CLI (cmd/)                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐            │
│  │  build   │  │   run    │  │ version  │            │
│  └────┬─────┘  └────┬─────┘  └──────────┘            │
└───────┼─────────────┼───────────────────────────────────┘
        │             │
        ▼             ▼
┌─────────────────────────────────────────────────────────┐
│                   Core Logic (pkg/)                     │
│                                                         │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐        │
│  │ Builder  │───→│ Capturer │───→│ Manifest │        │
│  └────┬─────┘    └──────────┘    └────┬─────┘        │
│       │                                 │              │
│       ▼                                 ▼              │
│  ┌──────────┐                      ┌──────────┐       │
│  │ Packager │←─────────────────────│  (JSON)  │       │
│  └────┬─────┘                      └──────────┘       │
│       │                                                │
│       ▼                                                │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐       │
│  │ Installer│───→│ Executor │───→│  Python  │       │
│  └──────────┘    └──────────┘    └──────────┘       │
└─────────────────────────────────────────────────────────┘
```

## Build Artifacts

When you build a project with PyExec, it creates:

```
myproject-v1.0.0                  # Executable binary
├── Embedded:
│   ├── manifest.json             # Environment description
│   ├── source.tar.gz             # Your source code
│   ├── (optional) python.tar.gz  # Python binary
│   └── (optional) deps.tar.gz    # Dependencies
└── Generated Go code:
    ├── Install command
    ├── Run command
    ├── Version command
    └── Verify command
```

## Installation Layout

After running `myproject-v1.0.0 install`:

```
~/.local/share/myproject/1.0.0/
├── bin/
│   └── python3                   # Standalone Python
├── lib/
│   ├── libssl.so.3              # System libraries
│   └── ...
├── .venv/
│   ├── bin/
│   │   └── python3              # Symlink
│   └── lib/
│       └── python3.12/
│           └── site-packages/   # Python packages
├── src/                         # Your source code
└── .pyexec/
    ├── manifest.json            # Installation manifest
    └── install.lock             # Installation metadata
```

## Development Workflow

### 1. Make Changes
```bash
# Edit code
vim pkg/builder/builder.go

# Format code
make fmt
```

### 2. Test Changes
```bash
# Run tests
make test

# Build binary
make build

# Test with example
make example
```

### 3. Submit Changes
```bash
# Commit
git add .
git commit -m "Add feature X"

# Push
git push origin feature-branch

# Create PR on GitHub
```

## Adding New Features

### Adding a New Command

1. Create `cmd/newcommand.go`
2. Define command with Cobra
3. Add to `cmd/root.go` init()
4. Implement command logic

### Adding a New Package

1. Create `pkg/newpackage/`
2. Create `pkg/newpackage/newpackage.go`
3. Define exported types and functions
4. Add tests in `pkg/newpackage/newpackage_test.go`

### Adding Documentation

1. Update relevant markdown files
2. Add code comments
3. Update examples if needed

## Testing

```bash
# Run all tests
go test ./...

# Run with coverage
go test -cover ./...

# Run specific package
go test ./pkg/builder/

# Run with verbose output
go test -v ./...
```

## Building

```bash
# Build for current platform
go build -o pyexec main.go

# Build for Linux
GOOS=linux GOARCH=amd64 go build -o pyexec-linux main.go

# Build for multiple platforms
make build-all
```

## Distribution

PyExec itself can be distributed as:
1. Source code (for developers)
2. Pre-built binaries (for users)
3. Docker image (for CI/CD)
4. Package managers (homebrew, apt, etc.)
