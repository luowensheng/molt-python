# Contributing to PyExec

Thank you for your interest in contributing to PyExec! This document provides guidelines for contributing.

## Development Setup

### Prerequisites

- Go 1.21 or later
- Python 3.12 or later
- UV package manager
- Git

### Getting Started

1. Fork the repository
2. Clone your fork:
   ```bash
   git clone https://pyexec
   cd pyexec
   ```

3. Install dependencies:
   ```bash
   go mod download
   ```

4. Build the project:
   ```bash
   make build
   ```

5. Run tests:
   ```bash
   make test
   ```

## Project Structure

```
pyexec/
├── cmd/                    # Command-line interface
│   ├── root.go            # Root command
│   ├── build.go           # Build command
│   └── version.go         # Version command
├── pkg/                   # Core packages
│   ├── builder/           # Build orchestration
│   ├── capture/           # Environment capture
│   ├── manifest/          # Manifest generation
│   └── packager/          # Binary packaging
├── examples/              # Example projects
├── main.go               # Entry point
└── README.md             # Documentation
```

## Making Changes

### Code Style

- Follow standard Go conventions
- Run `make fmt` before committing
- Run `make lint` to check for issues
- Add comments for exported functions and types

### Testing

- Write tests for new functionality
- Ensure all tests pass: `make test`
- Test on multiple Linux distributions if possible

### Commits

- Use clear, descriptive commit messages
- Reference issues in commit messages (e.g., "Fixes #123")
- Keep commits focused and atomic

Example commit message:
```
Add support for ARM64 architecture

- Add ARM64 detection in capture package
- Update manifest to include architecture
- Add tests for ARM64 builds

Fixes #123
```

## Pull Requests

1. Create a new branch for your feature:
   ```bash
   git checkout -b feature/my-new-feature
   ```

2. Make your changes and commit them

3. Push to your fork:
   ```bash
   git push origin feature/my-new-feature
   ```

4. Create a Pull Request on GitHub

### PR Guidelines

- Provide a clear description of changes
- Reference related issues
- Include tests for new functionality
- Update documentation as needed
- Ensure CI passes

## Areas for Contribution

### High Priority

- [ ] Implement full installer with download capabilities
- [ ] Add Linux namespace isolation in executor
- [ ] Implement signature verification
- [ ] Add caching system for downloads
- [ ] Support for additional architectures (ARM64)

### Medium Priority

- [ ] Improve error messages
- [ ] Add progress bars for downloads
- [ ] Implement version management commands
- [ ] Add support for custom mirrors
- [ ] Create comprehensive test suite

### Low Priority

- [ ] Add Docker comparison benchmarks
- [ ] Create more example projects
- [ ] Improve documentation with diagrams
- [ ] Add shell completions
- [ ] Create homebrew formula

## Feature Requests

Feature requests are welcome! Please:

1. Check if the feature already exists or is planned
2. Open an issue with the "enhancement" label
3. Clearly describe the use case and benefits
4. Provide examples if possible

## Bug Reports

When reporting bugs, please include:

1. PyExec version (`pyexec version`)
2. Operating system and version
3. Go version
4. Steps to reproduce
5. Expected behavior
6. Actual behavior
7. Error messages or logs

## Questions

For questions:

- Check the [README](README.md) first
- Search existing issues
- Open a new issue with the "question" label

## Code of Conduct

### Our Standards

- Be respectful and inclusive
- Welcome newcomers
- Focus on constructive feedback
- Accept constructive criticism gracefully

### Unacceptable Behavior

- Harassment or discrimination
- Trolling or insulting comments
- Publishing private information
- Any unethical or unprofessional conduct

## License

By contributing to PyExec, you agree that your contributions will be licensed under the MIT License.

## Recognition

Contributors will be recognized in:
- The README.md contributors section
- Release notes for significant contributions
- The project's AUTHORS file

Thank you for contributing to PyExec!
