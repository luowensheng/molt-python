package cmd

import (
	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "pyexec",
	Short: "PyExec - Hermetic Python Application Distribution",
	Long: `PyExec is a distribution system for Python applications that provides
Docker-level reproducibility with executable-sized binaries.

It combines UV's deterministic dependency management, standalone Python builds,
Linux namespaces for isolation, and Go's single-binary distribution.`,
}

func Execute() error {
	return rootCmd.Execute()
}

func init() {
	rootCmd.AddCommand(buildCmd)
	rootCmd.AddCommand(versionCmd)
}
