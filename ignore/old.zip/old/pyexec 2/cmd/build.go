package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/pyexec/pyexec/pkg/builder"
	"github.com/spf13/cobra"
)

var (
	buildProfile    string
	buildVersion    string
	buildName       string
	embedPython     bool
	embedCommonLibs bool
	offline         bool
	signKey         string
	maxSize         string
)

var buildCmd = &cobra.Command{
	Use:   "build [project-path]",
	Short: "Build a PyExec binary from a Python project",
	Long: `Build a PyExec binary from a Python project.

The project must contain:
  - pyproject.toml (project metadata)
  - uv.lock (exact dependencies)
  - Source code

Example:
  pyexec build --profile standard ./myproject
  pyexec build --profile full --offline ./myproject`,
	Args: cobra.ExactArgs(1),
	RunE: runBuild,
}

func init() {
	buildCmd.Flags().StringVar(&buildProfile, "profile", "standard", "Build profile (minimal, standard, extended, full)")
	buildCmd.Flags().StringVar(&buildVersion, "version", "", "Version of the application")
	buildCmd.Flags().StringVar(&buildName, "name", "", "Name of the application (defaults to project name)")
	buildCmd.Flags().BoolVar(&embedPython, "embed-python", false, "Embed Python binary (implied by standard+ profiles)")
	buildCmd.Flags().BoolVar(&embedCommonLibs, "embed-common-libs", false, "Embed common system libraries")
	buildCmd.Flags().BoolVar(&offline, "offline", false, "Create fully offline-capable binary")
	buildCmd.Flags().StringVar(&signKey, "sign-key", "", "Path to private key for signing")
	buildCmd.Flags().StringVar(&maxSize, "max-size", "", "Maximum binary size (e.g., 50MB)")
}

func runBuild(cmd *cobra.Command, args []string) error {
	projectPath := args[0]

	// Resolve absolute path
	absPath, err := filepath.Abs(projectPath)
	if err != nil {
		return fmt.Errorf("failed to resolve project path: %w", err)
	}

	// Check if project exists
	if _, err := os.Stat(absPath); os.IsNotExist(err) {
		return fmt.Errorf("project path does not exist: %s", absPath)
	}

	// Create builder config
	config := &builder.Config{
		ProjectPath:     absPath,
		Profile:         builder.Profile(buildProfile),
		Version:         buildVersion,
		Name:            buildName,
		EmbedPython:     embedPython,
		EmbedCommonLibs: embedCommonLibs,
		Offline:         offline,
		SignKey:         signKey,
		MaxSize:         maxSize,
	}

	// Adjust config based on profile
	if err := config.NormalizeProfile(); err != nil {
		return err
	}

	// Create builder
	b := builder.New(config)

	// Run build
	fmt.Printf("Building %s...\n", config.ProjectName())
	result, err := b.Build()
	if err != nil {
		return fmt.Errorf("build failed: %w", err)
	}

	// Print results
	fmt.Printf("\n✓ Build successful!\n")
	fmt.Printf("  Binary: %s (%s)\n", result.OutputPath, result.HumanSize())
	fmt.Printf("  Profile: %s\n", result.Profile)
	fmt.Printf("  Python: %s\n", result.PythonVersion)
	fmt.Printf("  Packages: %d\n", result.PackageCount)
	fmt.Printf("  System deps: %d\n", result.SystemDepCount)

	return nil
}
