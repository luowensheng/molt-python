package capture

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"

	"gopkg.in/yaml.v3"
)

// Snapshot represents a captured environment
type Snapshot struct {
	Python     PythonInfo
	SystemDeps []SystemDep
	Packages   []Package
	Source     SourceInfo
}

// PythonInfo contains Python binary information
type PythonInfo struct {
	Version  string
	Path     string
	URL      string
	Checksum string
	Size     int64
}

// SystemDep represents a system library dependency
type SystemDep struct {
	Name        string
	Path        string
	Version     string
	PackageName string
	URL         string
	Checksum    string
	Size        int64
}

// Package represents a Python package
type Package struct {
	Name     string
	Version  string
	URL      string
	Checksum string
	Size     int64
}

// SourceInfo contains source code information
type SourceInfo struct {
	Path  string
	Files []string
	Size  int64
}

// UVLock represents the structure of uv.lock
type UVLock struct {
	Version  int         `yaml:"version"`
	Packages []UVPackage `yaml:"package"`
}

// UVPackage represents a package in uv.lock
type UVPackage struct {
	Name    string     `yaml:"name"`
	Version string     `yaml:"version"`
	Source  UVSource   `yaml:"source"`
	Wheels  []UVWheel  `yaml:"wheels,omitempty"`
}

// UVSource represents the source of a package
type UVSource struct {
	Type     string `yaml:"registry,omitempty"`
	URL      string `yaml:"url,omitempty"`
	Registry string `yaml:"index,omitempty"`
}

// UVWheel represents a wheel file
type UVWheel struct {
	URL  string `yaml:"url"`
	Hash string `yaml:"hash"`
	Size int    `yaml:"size,omitempty"`
}

// Capturer captures environment information
type Capturer struct{}

// New creates a new Capturer
func New() *Capturer {
	return &Capturer{}
}

// Capture captures the complete environment
func (c *Capturer) Capture(projectPath string) (*Snapshot, error) {
	snapshot := &Snapshot{}

	// Capture Python
	python, err := c.capturePython(projectPath)
	if err != nil {
		return nil, fmt.Errorf("failed to capture Python: %w", err)
	}
	snapshot.Python = python

	// Capture system dependencies
	sysDeps, err := c.captureSystemDeps(projectPath, python.Path)
	if err != nil {
		return nil, fmt.Errorf("failed to capture system dependencies: %w", err)
	}
	snapshot.SystemDeps = sysDeps

	// Capture Python packages
	packages, err := c.capturePackages(projectPath)
	if err != nil {
		return nil, fmt.Errorf("failed to capture packages: %w", err)
	}
	snapshot.Packages = packages

	// Capture source
	source, err := c.captureSource(projectPath)
	if err != nil {
		return nil, fmt.Errorf("failed to capture source: %w", err)
	}
	snapshot.Source = source

	return snapshot, nil
}

// capturePython captures Python binary information
func (c *Capturer) capturePython(projectPath string) (PythonInfo, error) {
	// Try to find Python in venv
	venvPython := filepath.Join(projectPath, ".venv", "bin", "python3")
	
	var pythonPath string
	if _, err := os.Stat(venvPython); err == nil {
		pythonPath = venvPython
	} else {
		// Fall back to system Python
		path, err := exec.LookPath("python3")
		if err != nil {
			return PythonInfo{}, fmt.Errorf("python3 not found")
		}
		pythonPath = path
	}

	// Get version
	cmd := exec.Command(pythonPath, "--version")
	output, err := cmd.Output()
	if err != nil {
		return PythonInfo{}, fmt.Errorf("failed to get Python version: %w", err)
	}

	version := strings.TrimSpace(strings.TrimPrefix(string(output), "Python "))

	// Get checksum
	checksum, size, err := c.fileChecksum(pythonPath)
	if err != nil {
		return PythonInfo{}, fmt.Errorf("failed to checksum Python: %w", err)
	}

	// Generate download URL (using python-build-standalone)
	url := fmt.Sprintf("https://github.com/indygreg/python-build-standalone/releases/download/20231002/cpython-%s+20231002-x86_64-unknown-linux-gnu-install_only.tar.gz", version)

	return PythonInfo{
		Version:  version,
		Path:     pythonPath,
		URL:      url,
		Checksum: checksum,
		Size:     size,
	}, nil
}

// captureSystemDeps captures system library dependencies
func (c *Capturer) captureSystemDeps(projectPath, pythonPath string) ([]SystemDep, error) {
	deps := []SystemDep{}

	// Run ldd on Python binary
	cmd := exec.Command("ldd", pythonPath)
	output, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("ldd failed: %w", err)
	}

	// Parse ldd output
	scanner := bufio.NewScanner(bytes.NewReader(output))
	libRegex := regexp.MustCompile(`^\s*(.+?)\s+=>\s+(.+?)\s+\(0x[0-9a-f]+\)`)

	for scanner.Scan() {
		line := scanner.Text()
		matches := libRegex.FindStringSubmatch(line)
		if len(matches) == 3 {
			libName := strings.TrimSpace(matches[1])
			libPath := strings.TrimSpace(matches[2])

			// Skip vdso and other special libraries
			if strings.Contains(libPath, "vdso") || libPath == "" {
				continue
			}

			// Get checksum
			checksum, size, err := c.fileChecksum(libPath)
			if err != nil {
				continue
			}

			deps = append(deps, SystemDep{
				Name:     libName,
				Path:     libPath,
				Checksum: checksum,
				Size:     size,
			})
		}
	}

	// Also check for native extensions in site-packages
	sitePackages := filepath.Join(projectPath, ".venv", "lib", "python*", "site-packages")
	matches, _ := filepath.Glob(sitePackages)
	for _, sp := range matches {
		extDeps, _ := c.findNativeExtensionDeps(sp)
		deps = append(deps, extDeps...)
	}

	// Deduplicate
	return c.deduplicateDeps(deps), nil
}

// findNativeExtensionDeps finds dependencies of native extensions
func (c *Capturer) findNativeExtensionDeps(sitePackagesPath string) ([]SystemDep, error) {
	deps := []SystemDep{}

	err := filepath.Walk(sitePackagesPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if filepath.Ext(path) == ".so" {
			// Run ldd on .so file
			cmd := exec.Command("ldd", path)
			output, _ := cmd.Output()

			scanner := bufio.NewScanner(bytes.NewReader(output))
			libRegex := regexp.MustCompile(`^\s*(.+?)\s+=>\s+(.+?)\s+\(0x[0-9a-f]+\)`)

			for scanner.Scan() {
				line := scanner.Text()
				matches := libRegex.FindStringSubmatch(line)
				if len(matches) == 3 {
					libPath := strings.TrimSpace(matches[2])
					if libPath != "" && !strings.Contains(libPath, "vdso") {
						checksum, size, _ := c.fileChecksum(libPath)
						deps = append(deps, SystemDep{
							Name:     filepath.Base(libPath),
							Path:     libPath,
							Checksum: checksum,
							Size:     size,
						})
					}
				}
			}
		}
		return nil
	})

	return deps, err
}

// capturePackages parses uv.lock and captures package information
func (c *Capturer) capturePackages(projectPath string) ([]Package, error) {
	lockPath := filepath.Join(projectPath, "uv.lock")

	data, err := os.ReadFile(lockPath)
	if err != nil {
		return nil, err
	}

	var lock UVLock
	if err := yaml.Unmarshal(data, &lock); err != nil {
		return nil, fmt.Errorf("failed to parse uv.lock: %w", err)
	}

	packages := []Package{}
	for _, pkg := range lock.Packages {
		p := Package{
			Name:    pkg.Name,
			Version: pkg.Version,
		}

		// Get URL and checksum from wheels
		if len(pkg.Wheels) > 0 {
			wheel := pkg.Wheels[0]
			p.URL = wheel.URL
			p.Checksum = wheel.Hash
			p.Size = int64(wheel.Size)
		} else {
			// Construct PyPI URL
			p.URL = fmt.Sprintf("https://files.pythonhosted.org/packages/source/%s/%s/%s-%s.tar.gz",
				pkg.Name[0:1], pkg.Name, pkg.Name, pkg.Version)
		}

		packages = append(packages, p)
	}

	return packages, nil
}

// captureSource captures source code information
func (c *Capturer) captureSource(projectPath string) (SourceInfo, error) {
	files := []string{}
	var totalSize int64

	err := filepath.Walk(projectPath, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}

		// Skip hidden directories, venv, and cache
		if info.IsDir() {
			name := info.Name()
			if strings.HasPrefix(name, ".") || name == "__pycache__" || name == "node_modules" {
				return filepath.SkipDir
			}
			return nil
		}

		// Only include Python files and config files
		ext := filepath.Ext(path)
		if ext == ".py" || ext == ".toml" || ext == ".lock" || ext == ".yaml" || ext == ".yml" {
			relPath, _ := filepath.Rel(projectPath, path)
			files = append(files, relPath)
			totalSize += info.Size()
		}

		return nil
	})

	return SourceInfo{
		Path:  projectPath,
		Files: files,
		Size:  totalSize,
	}, err
}

// fileChecksum calculates SHA256 checksum of a file
func (c *Capturer) fileChecksum(path string) (string, int64, error) {
	file, err := os.Open(path)
	if err != nil {
		return "", 0, err
	}
	defer file.Close()

	hash := sha256.New()
	size, err := io.Copy(hash, file)
	if err != nil {
		return "", 0, err
	}

	return fmt.Sprintf("%x", hash.Sum(nil)), size, nil
}

// deduplicateDeps removes duplicate dependencies
func (c *Capturer) deduplicateDeps(deps []SystemDep) []SystemDep {
	seen := make(map[string]bool)
	result := []SystemDep{}

	for _, dep := range deps {
		if !seen[dep.Path] {
			seen[dep.Path] = true
			result = append(result, dep)
		}
	}

	return result
}
