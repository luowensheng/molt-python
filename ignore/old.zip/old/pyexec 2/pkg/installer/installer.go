package installer

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"

	"github.com/pyexec/pyexec/pkg/manifest"
)

// InstallMode defines the installation mode
type InstallMode string

const (
	ModeMinimal    InstallMode = "minimal"
	ModeStandalone InstallMode = "standalone"
	ModeExact      InstallMode = "exact"
)

// Config holds installer configuration
type Config struct {
	Manifest    *manifest.Manifest
	Mode        InstallMode
	InstallPath string
	CacheDir    string
	Offline     bool
	Parallel    int
}

// Installer handles installation of PyExec applications
type Installer struct {
	config   *Config
	cache    *Cache
	verifier *Verifier
}

// New creates a new Installer
func New(config *Config) *Installer {
	return &Installer{
		config:   config,
		cache:    NewCache(config.CacheDir),
		verifier: NewVerifier(),
	}
}

// Install performs the installation
func (i *Installer) Install() error {
	fmt.Println("Installing application...")

	// Phase 1: Create installation directory
	if err := os.MkdirAll(i.config.InstallPath, 0755); err != nil {
		return fmt.Errorf("failed to create install directory: %w", err)
	}

	// Phase 2: Install Python
	fmt.Println("✓ Installing Python...")
	if err := i.installPython(); err != nil {
		return fmt.Errorf("failed to install Python: %w", err)
	}

	// Phase 3: Install system dependencies (if standalone mode)
	if i.config.Mode >= ModeStandalone {
		fmt.Println("✓ Installing system dependencies...")
		if err := i.installSystemDeps(); err != nil {
			return fmt.Errorf("failed to install system deps: %w", err)
		}
	}

	// Phase 4: Create virtual environment
	fmt.Println("✓ Creating virtual environment...")
	if err := i.createVenv(); err != nil {
		return fmt.Errorf("failed to create venv: %w", err)
	}

	// Phase 5: Install Python packages
	fmt.Println("✓ Installing packages...")
	if err := i.installPackages(); err != nil {
		return fmt.Errorf("failed to install packages: %w", err)
	}

	// Phase 6: Verify (if exact mode)
	if i.config.Mode == ModeExact {
		fmt.Println("✓ Verifying installation...")
		if err := i.verifier.Verify(i.config.InstallPath, i.config.Manifest); err != nil {
			return fmt.Errorf("verification failed: %w", err)
		}
	}

	fmt.Printf("\n✓ Installation complete!\n")
	fmt.Printf("  Location: %s\n", i.config.InstallPath)

	return nil
}

// installPython installs the Python binary
func (i *Installer) installPython() error {
	pythonManifest := i.config.Manifest.Python

	// Check cache first
	if cached := i.cache.Get(pythonManifest.Checksum); cached != "" {
		return i.extractPython(cached)
	}

	// Download Python
	pythonPath := filepath.Join(i.config.InstallPath, "python.tar.gz")
	if err := i.download(pythonManifest.URL, pythonPath, pythonManifest.Checksum); err != nil {
		return err
	}

	// Cache for future use
	i.cache.Set(pythonManifest.Checksum, pythonPath)

	// Extract
	return i.extractPython(pythonPath)
}

// installSystemDeps installs system dependencies
func (i *Installer) installSystemDeps() error {
	libDir := filepath.Join(i.config.InstallPath, "lib")
	if err := os.MkdirAll(libDir, 0755); err != nil {
		return err
	}

	for _, dep := range i.config.Manifest.SystemDeps {
		targetPath := filepath.Join(libDir, dep.Name)

		// Check cache
		if cached := i.cache.Get(dep.Checksum); cached != "" {
			if err := i.copyFile(cached, targetPath); err != nil {
				return err
			}
			continue
		}

		// Download
		if dep.URL != "" {
			if err := i.download(dep.URL, targetPath, dep.Checksum); err != nil {
				return fmt.Errorf("failed to download %s: %w", dep.Name, err)
			}
			i.cache.Set(dep.Checksum, targetPath)
		}
	}

	return nil
}

// createVenv creates a Python virtual environment
func (i *Installer) createVenv() error {
	pythonBin := filepath.Join(i.config.InstallPath, "bin", "python3")
	venvPath := filepath.Join(i.config.InstallPath, ".venv")

	// Create venv
	// In a real implementation, this would use python -m venv
	if err := os.MkdirAll(venvPath, 0755); err != nil {
		return err
	}

	// Symlink Python
	venvBin := filepath.Join(venvPath, "bin")
	if err := os.MkdirAll(venvBin, 0755); err != nil {
		return err
	}

	return os.Symlink(pythonBin, filepath.Join(venvBin, "python3"))
}

// installPackages installs Python packages
func (i *Installer) installPackages() error {
	for _, pkg := range i.config.Manifest.Packages {
		// Check cache
		if cached := i.cache.Get(pkg.Checksum); cached != "" {
			continue // Package already cached
		}

		// Download
		pkgPath := filepath.Join(i.config.CacheDir, fmt.Sprintf("%s-%s.whl", pkg.Name, pkg.Version))
		if err := i.download(pkg.URL, pkgPath, pkg.Checksum); err != nil {
			return fmt.Errorf("failed to download %s: %w", pkg.Name, err)
		}

		i.cache.Set(pkg.Checksum, pkgPath)
	}

	// In a real implementation, this would use pip or uv to install packages
	return nil
}

// extractPython extracts the Python archive
func (i *Installer) extractPython(archivePath string) error {
	// In a real implementation, this would extract the tar.gz
	// For now, we'll just create the expected directory structure
	binDir := filepath.Join(i.config.InstallPath, "bin")
	return os.MkdirAll(binDir, 0755)
}

// download downloads a file from a URL and verifies its checksum
func (i *Installer) download(url, dest, expectedChecksum string) error {
	// Create destination directory
	if err := os.MkdirAll(filepath.Dir(dest), 0755); err != nil {
		return err
	}

	// Download
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("download failed: %s", resp.Status)
	}

	// Create file
	file, err := os.Create(dest)
	if err != nil {
		return err
	}
	defer file.Close()

	// Copy and hash
	hash := sha256.New()
	writer := io.MultiWriter(file, hash)

	if _, err := io.Copy(writer, resp.Body); err != nil {
		return err
	}

	// Verify checksum
	actualChecksum := hex.EncodeToString(hash.Sum(nil))
	if actualChecksum != expectedChecksum {
		os.Remove(dest)
		return fmt.Errorf("checksum mismatch: expected %s, got %s", expectedChecksum, actualChecksum)
	}

	return nil
}

// copyFile copies a file
func (i *Installer) copyFile(src, dst string) error {
	source, err := os.Open(src)
	if err != nil {
		return err
	}
	defer source.Close()

	destination, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer destination.Close()

	_, err = io.Copy(destination, source)
	return err
}

// Cache manages downloaded files
type Cache struct {
	dir string
}

// NewCache creates a new Cache
func NewCache(dir string) *Cache {
	os.MkdirAll(dir, 0755)
	return &Cache{dir: dir}
}

// Get retrieves a cached file by checksum
func (c *Cache) Get(checksum string) string {
	path := filepath.Join(c.dir, checksum)
	if _, err := os.Stat(path); err == nil {
		return path
	}
	return ""
}

// Set caches a file by checksum
func (c *Cache) Set(checksum, path string) error {
	cachePath := filepath.Join(c.dir, checksum)
	return os.Link(path, cachePath)
}

// Verifier verifies installation integrity
type Verifier struct{}

// NewVerifier creates a new Verifier
func NewVerifier() *Verifier {
	return &Verifier{}
}

// Verify verifies the installation
func (v *Verifier) Verify(installPath string, manifest *manifest.Manifest) error {
	// In a real implementation, this would:
	// 1. Verify all file checksums
	// 2. Check Python version
	// 3. Verify all packages are installed
	// 4. Test imports

	return nil
}
