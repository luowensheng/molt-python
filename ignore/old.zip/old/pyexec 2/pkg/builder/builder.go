package builder

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/pyexec/pyexec/pkg/capture"
	"github.com/pyexec/pyexec/pkg/manifest"
	"github.com/pyexec/pyexec/pkg/packager"
)

// Profile defines the build profile
type Profile string

const (
	ProfileMinimal  Profile = "minimal"
	ProfileStandard Profile = "standard"
	ProfileExtended Profile = "extended"
	ProfileFull     Profile = "full"
)

// Config holds the build configuration
type Config struct {
	ProjectPath     string
	Profile         Profile
	Version         string
	Name            string
	EmbedPython     bool
	EmbedCommonLibs bool
	Offline         bool
	SignKey         string
	MaxSize         string
}

// NormalizeProfile adjusts config based on profile
func (c *Config) NormalizeProfile() error {
	switch c.Profile {
	case ProfileMinimal:
		// Nothing embedded by default
	case ProfileStandard:
		c.EmbedPython = true
	case ProfileExtended:
		c.EmbedPython = true
		c.EmbedCommonLibs = true
	case ProfileFull:
		c.EmbedPython = true
		c.EmbedCommonLibs = true
		c.Offline = true
	default:
		return fmt.Errorf("unknown profile: %s (valid: minimal, standard, extended, full)", c.Profile)
	}
	return nil
}

// ProjectName returns the project name
func (c *Config) ProjectName() string {
	if c.Name != "" {
		return c.Name
	}
	return filepath.Base(c.ProjectPath)
}

// OutputName returns the output binary name
func (c *Config) OutputName() string {
	name := c.ProjectName()
	if c.Version != "" {
		name = fmt.Sprintf("%s-v%s", name, strings.TrimPrefix(c.Version, "v"))
	}
	if c.Offline {
		name += "-offline"
	}
	return name
}

// Builder builds PyExec binaries
type Builder struct {
	config   *Config
	capturer *capture.Capturer
	packager *packager.Packager
}

// New creates a new Builder
func New(config *Config) *Builder {
	return &Builder{
		config:   config,
		capturer: capture.New(),
		packager: packager.New(),
	}
}

// BuildResult contains the build results
type BuildResult struct {
	OutputPath      string
	Profile         Profile
	PythonVersion   string
	PackageCount    int
	SystemDepCount  int
	BinarySize      int64
}

// HumanSize returns human-readable size
func (r *BuildResult) HumanSize() string {
	const unit = 1024
	if r.BinarySize < unit {
		return fmt.Sprintf("%d B", r.BinarySize)
	}
	div, exp := int64(unit), 0
	for n := r.BinarySize / unit; n >= unit; n /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %cB", float64(r.BinarySize)/float64(div), "KMGTPE"[exp])
}

// Build executes the build process
func (b *Builder) Build() (*BuildResult, error) {
	// Phase 1: Validate project
	fmt.Println("✓ Validating project structure...")
	if err := b.validateProject(); err != nil {
		return nil, fmt.Errorf("validation failed: %w", err)
	}

	// Phase 2: Capture environment
	fmt.Println("✓ Capturing environment...")
	snapshot, err := b.capturer.Capture(b.config.ProjectPath)
	if err != nil {
		return nil, fmt.Errorf("capture failed: %w", err)
	}

	// Phase 3: Generate manifest
	fmt.Println("✓ Generating manifest...")
	m := manifest.FromSnapshot(snapshot)

	// Phase 4: Package binary
	fmt.Println("✓ Packaging binary...")
	outputPath := filepath.Join(b.config.ProjectPath, b.config.OutputName())
	
	packageConfig := &packager.Config{
		Manifest:        m,
		OutputPath:      outputPath,
		EmbedPython:     b.config.EmbedPython,
		EmbedCommonLibs: b.config.EmbedCommonLibs,
		EmbedAllDeps:    b.config.Offline,
		SourcePath:      b.config.ProjectPath,
	}

	if err := b.packager.Package(packageConfig); err != nil {
		return nil, fmt.Errorf("packaging failed: %w", err)
	}

	// Get file size
	stat, err := os.Stat(outputPath)
	if err != nil {
		return nil, fmt.Errorf("failed to stat output: %w", err)
	}

	return &BuildResult{
		OutputPath:     outputPath,
		Profile:        b.config.Profile,
		PythonVersion:  snapshot.Python.Version,
		PackageCount:   len(snapshot.Packages),
		SystemDepCount: len(snapshot.SystemDeps),
		BinarySize:     stat.Size(),
	}, nil
}

// validateProject checks if the project is valid
func (b *Builder) validateProject() error {
	// Check pyproject.toml
	pyprojectPath := filepath.Join(b.config.ProjectPath, "pyproject.toml")
	if _, err := os.Stat(pyprojectPath); os.IsNotExist(err) {
		return fmt.Errorf("pyproject.toml not found in %s", b.config.ProjectPath)
	}

	// Check uv.lock
	lockPath := filepath.Join(b.config.ProjectPath, "uv.lock")
	if _, err := os.Stat(lockPath); os.IsNotExist(err) {
		return fmt.Errorf("uv.lock not found in %s (run 'uv lock' first)", b.config.ProjectPath)
	}

	return nil
}
