package manifest

import (
	"encoding/json"

	"github.com/pyexec/pyexec/pkg/capture"
)

// Manifest represents the complete environment manifest
type Manifest struct {
	Version    string            `json:"version"`
	Python     PythonManifest    `json:"python"`
	SystemDeps []SystemDepManifest `json:"system_deps"`
	Packages   []PackageManifest `json:"packages"`
	Source     SourceManifest    `json:"source"`
}

// PythonManifest contains Python binary information
type PythonManifest struct {
	Version  string `json:"version"`
	URL      string `json:"url"`
	Checksum string `json:"checksum"`
	Size     int64  `json:"size"`
}

// SystemDepManifest contains system dependency information
type SystemDepManifest struct {
	Name        string `json:"name"`
	Version     string `json:"version,omitempty"`
	PackageName string `json:"package_name,omitempty"`
	URL         string `json:"url,omitempty"`
	Checksum    string `json:"checksum"`
	Size        int64  `json:"size"`
}

// PackageManifest contains Python package information
type PackageManifest struct {
	Name     string `json:"name"`
	Version  string `json:"version"`
	URL      string `json:"url"`
	Checksum string `json:"checksum"`
	Size     int64  `json:"size"`
}

// SourceManifest contains source code information
type SourceManifest struct {
	Files []string `json:"files"`
	Size  int64    `json:"size"`
}

// FromSnapshot creates a Manifest from a Snapshot
func FromSnapshot(s *capture.Snapshot) *Manifest {
	m := &Manifest{
		Version: "1.0",
		Python: PythonManifest{
			Version:  s.Python.Version,
			URL:      s.Python.URL,
			Checksum: s.Python.Checksum,
			Size:     s.Python.Size,
		},
	}

	// System dependencies
	for _, dep := range s.SystemDeps {
		m.SystemDeps = append(m.SystemDeps, SystemDepManifest{
			Name:        dep.Name,
			Version:     dep.Version,
			PackageName: dep.PackageName,
			URL:         dep.URL,
			Checksum:    dep.Checksum,
			Size:        dep.Size,
		})
	}

	// Packages
	for _, pkg := range s.Packages {
		m.Packages = append(m.Packages, PackageManifest{
			Name:     pkg.Name,
			Version:  pkg.Version,
			URL:      pkg.URL,
			Checksum: pkg.Checksum,
			Size:     pkg.Size,
		})
	}

	// Source
	m.Source = SourceManifest{
		Files: s.Source.Files,
		Size:  s.Source.Size,
	}

	return m
}

// ToJSON serializes the manifest to JSON
func (m *Manifest) ToJSON() ([]byte, error) {
	return json.MarshalIndent(m, "", "  ")
}

// FromJSON deserializes a manifest from JSON
func FromJSON(data []byte) (*Manifest, error) {
	var m Manifest
	err := json.Unmarshal(data, &m)
	return &m, err
}
