package executor

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"syscall"

	"github.com/pyexec/pyexec/pkg/manifest"
)

// Config holds executor configuration
type Config struct {
	InstallPath  string
	Manifest     *manifest.Manifest
	UseNamespace bool
	Isolated     bool
}

// Executor executes Python applications
type Executor struct {
	config *Config
}

// New creates a new Executor
func New(config *Config) *Executor {
	return &Executor{config: config}
}

// Run executes the Python application
func (e *Executor) Run(args []string) error {
	// Verify installation
	if err := e.verifyInstallation(); err != nil {
		return fmt.Errorf("installation verification failed: %w", err)
	}

	// Build command
	pythonBin := filepath.Join(e.config.InstallPath, ".venv", "bin", "python3")
	
	// Create command
	cmd := exec.Command(pythonBin, args...)

	// Set up environment
	cmd.Env = e.buildEnvironment()

	// Set up namespace (Linux only)
	if runtime.GOOS == "linux" && e.config.UseNamespace {
		cmd.SysProcAttr = &syscall.SysProcAttr{
			Cloneflags: syscall.CLONE_NEWNS | syscall.CLONE_NEWPID | syscall.CLONE_NEWUTS,
		}
	}

	// Connect standard I/O
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Stdin = os.Stdin

	// Execute
	return cmd.Run()
}

// verifyInstallation verifies that the installation is intact
func (e *Executor) verifyInstallation() error {
	// Check if installation directory exists
	if _, err := os.Stat(e.config.InstallPath); os.IsNotExist(err) {
		return fmt.Errorf("installation not found at %s", e.config.InstallPath)
	}

	// Check if Python binary exists
	pythonBin := filepath.Join(e.config.InstallPath, ".venv", "bin", "python3")
	if _, err := os.Stat(pythonBin); os.IsNotExist(err) {
		return fmt.Errorf("Python binary not found: %s", pythonBin)
	}

	// Check if manifest exists
	manifestPath := filepath.Join(e.config.InstallPath, ".pyexec", "manifest.json")
	if _, err := os.Stat(manifestPath); os.IsNotExist(err) {
		return fmt.Errorf("manifest not found: %s", manifestPath)
	}

	return nil
}

// buildEnvironment builds the execution environment
func (e *Executor) buildEnvironment() []string {
	installPath := e.config.InstallPath

	env := []string{
		// Library path (isolated libs first)
		fmt.Sprintf("LD_LIBRARY_PATH=%s:%s",
			filepath.Join(installPath, "lib"),
			os.Getenv("LD_LIBRARY_PATH"),
		),

		// Python home
		fmt.Sprintf("PYTHONHOME=%s", filepath.Join(installPath, ".venv")),

		// PATH
		fmt.Sprintf("PATH=%s:%s:%s",
			filepath.Join(installPath, "bin"),
			filepath.Join(installPath, ".venv", "bin"),
			os.Getenv("PATH"),
		),

		// Prevent Python from using system packages
		"PYTHONNOUSERSITE=1",

		// Clean Python startup
		"PYTHONDONTWRITEBYTECODE=1",

		// Preserve some important env vars
		fmt.Sprintf("HOME=%s", os.Getenv("HOME")),
		fmt.Sprintf("USER=%s", os.Getenv("USER")),
		fmt.Sprintf("TERM=%s", os.Getenv("TERM")),
	}

	// If isolated, don't inherit other environment variables
	if !e.config.Isolated {
		env = append(env, os.Environ()...)
	}

	return env
}

// GetPythonVersion returns the Python version being used
func (e *Executor) GetPythonVersion() (string, error) {
	pythonBin := filepath.Join(e.config.InstallPath, ".venv", "bin", "python3")
	
	cmd := exec.Command(pythonBin, "--version")
	output, err := cmd.Output()
	if err != nil {
		return "", err
	}

	return string(output), nil
}

// CheckHealth performs a health check on the installation
func (e *Executor) CheckHealth() error {
	// Verify installation structure
	if err := e.verifyInstallation(); err != nil {
		return err
	}

	// Try to get Python version
	if _, err := e.GetPythonVersion(); err != nil {
		return fmt.Errorf("failed to get Python version: %w", err)
	}

	// Try to import sys
	pythonBin := filepath.Join(e.config.InstallPath, ".venv", "bin", "python3")
	cmd := exec.Command(pythonBin, "-c", "import sys; print(sys.version)")
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("failed to import sys: %w", err)
	}

	return nil
}
